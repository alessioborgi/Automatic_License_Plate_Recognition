import pandas as pd
import streamlit as st
import psycopg2
from PIL import Image  
import psycopg2.extensions
import select

def valid_plates_q():
        conn = psycopg2.connect(user="postgres",
                                    password="admin",
                                    host="127.0.0.1",
                                    port="5432",
                                    database="Employee_Detection_ALPR_Project")
        cursor = conn.cursor()
        postgreSQL_select_Query = 'select "License_Plate","ID_Employee" from "CAR"'
        dat = pd.read_sql_query(postgreSQL_select_Query, conn)
        conn=None
        print(dat)
        return dat

def presences_q():
        conn = psycopg2.connect(user="postgres",
                                    password="admin",
                                    host="127.0.0.1",
                                    port="5432",
                                    database="Employee_Detection_ALPR_Project")
        cursor = conn.cursor()
        postgreSQL_select_Query = 'select * from "PRESENCE"'
        dat = pd.read_sql_query(postgreSQL_select_Query, conn)
        conn=None
        print(dat)
        return dat

#@st.cache(suppress_st_warning=True)

def head():
    #image = Image.open('assets\image1.jpeg')
    #new_image = image.resize((80, 80))
    #st.image(new_image)
    st.markdown("""
        <h1 style='text-align: center; margin-bottom: -35px;'>
        AMG Company Access Manager
        </h1>
    """, unsafe_allow_html=True
    )
    
    st.caption("""
        <p style='text-align: center'>
        by Alessio Borgi, Martina Doku, Giusepina Iannotti
        </p>
    """, unsafe_allow_html=True
    )
    col1, col2, col3 = st.columns([2,6,1])
    with col2:
        image = Image.open('assets/image1.jpeg')
        new_image = image.resize((380, 380))
        st.image(new_image)


def external_view():
    conn = psycopg2.connect(user="postgres",
                                    password="admin",
                                    host="127.0.0.1",
                                    port="5432",
                                    database="Employee_Detection_ALPR_Project")
    conn.set_isolation_level(psycopg2.extensions.ISOLATION_LEVEL_AUTOCOMMIT)
    curs = conn.cursor()
    curs.execute('LISTEN "test";')
    #conn.set_isolation_level(ISOLATION_LEVEL_AUTOCOMMIT)
    print ("Waiting for notifications on channel 'test'")
    st.write('The gate is closed, please get close to get your plate identified!')
    while True:
        if select.select([conn],[],[],5) == ([],[],[]):
            print ("Timeout")
            
        else:
            conn.poll()
            while conn.notifies:
                notify = conn.notifies.pop()
                print(notify)
                #OBTAINING ID VALUE FROM THE PAYLOAD (THAT IS THE WHOLE ROW JUST INSERTED)
                payload=notify.payload.strip('{}')
                values=payload.split(',')
                print(values)
                ID_employee=values[3].split(':')
                ID_employee=ID_employee[1].strip('"')
                ID_employee=ID_employee.strip("'")
                #fetching the database for informations about the id
                curs.execute(f"""SELECT * FROM "EMPLOYEE" WHERE "ID_Employee"='{ID_employee}'""")
                e_values = curs.fetchall()[0][1:3]
                print('ID:',ID_employee,'Info',e_values)
                st.write('Welcome',e_values[0],e_values[1],'!')
    

               
