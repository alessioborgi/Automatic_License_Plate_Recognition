import streamlit as st
from utils import head, valid_plates_q, presences_q,external_view

st.set_page_config(
    page_title='AMG security',
    page_icon='assets/logo.png'
)


page = st.sidebar.selectbox('Menu',['Home','Accesses','Valid Plates','External View']) 
if page=='Home':
    head()

if page == 'Valid Plates':
    st.write(
            "Click the button to see admitted plates")
    if st.button("plates"):
        df = valid_plates_q()
        #valid_plates_show(df)
        st.dataframe(df.style.set_properties(**{'background-color': 'lightgrey',
                           'color': 'black'}))
if page=='Accesses':
    st.write(
            "Click the button to see last accesses")
    if st.button("access"):
        df = presences_q()
        #presences_show(df)
        st.dataframe(df.style.set_properties(**{'background-color': 'lightgrey',
                           'color': 'black'}))

if page=='External View':
    external_view()